document.querySelector('.menu-btn')?.addEventListener('click',()=>document.querySelector('.nav').classList.toggle('open'));

const styleData={};
document.querySelectorAll('.options').forEach(group=>{
  group.querySelectorAll('button').forEach(btn=>{
    btn.addEventListener('click',()=>{
      group.querySelectorAll('button').forEach(b=>b.classList.remove('active'));
      btn.classList.add('active');
      styleData[group.dataset.key]=btn.dataset.value;
    });
  });
});
const result=document.querySelector('.result');
const findBtn=document.querySelector('#find-style');
if(findBtn){
  findBtn.addEventListener('click',()=>{
    const occasion=styleData.occasion||'celebration';
    const silhouette=styleData.silhouette||'personalised';
    const mood=styleData.mood||'elegant';
    const map={
      bridal:'A statement bridal or festive look',
      festive:'A polished festive designer look',
      party:'A modern party look',
      casual:'A refined everyday custom look'
    };
    const silhouetteText={lehenga:'with a lehenga silhouette',blouse:'with a statement blouse',threepiece:'with a coordinated three-piece outfit',western:'with a contemporary western silhouette',personalised:'tailored around your preferred silhouette'};
    const moodText={elegant:'with an elegant, refined finish',bold:'with a bold statement finish',minimal:'with a clean, minimal finish',royal:'with a rich, royal finish'};
    result.innerHTML=`<strong>Your Style Direction</strong><p>${map[occasion]||map.festive} ${silhouetteText[silhouette]||silhouetteText.personalised}, ${moodText[mood]||moodText.elegant}.</p><a class="btn primary" href="https://wa.me/917567504456?text=${encodeURIComponent("Hi Dharmi's Boutique, I used your Style Finder and would like to discuss my look.")}" target="_blank">Discuss on WhatsApp</a>`;
    result.style.display='block';
  });
}
